import React from 'react';
import { Printer, X } from 'lucide-react';
import { experienceData, siteMeta } from '../data/portfolioData';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Mihir Vaidya Résumé"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="bg-white text-[#111111] max-w-[820px] w-full border border-[#E5E5E2] rounded-[32px] my-8 shadow-2xl relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Action Bar */}
        <div className="flex items-center justify-between border-b border-[#F0F0ED] px-6 sm:px-8 py-5 bg-[#F7F7F7]">
          <div className="font-sans text-[11px] uppercase tracking-[0.14em] text-[#8A8A87] font-bold">
            RÉSUMÉ DOSSIER / MIHIR VAIDYA
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 rounded-full border border-[#E5E5E2] bg-white hover:border-[#111111] text-[12px] font-sans uppercase font-bold tracking-wider flex items-center gap-1.5 text-[#111111] cursor-pointer transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-[#111111]" />
              <span>Print / PDF</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close résumé"
              className="w-10 h-10 rounded-full border border-[#E5E5E2] bg-white hover:border-[#111111] flex items-center justify-center text-[#111111] cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Résumé Document */}
        <div className="p-8 sm:p-12 space-y-10" id="printable-resume">
          {/* Header */}
          <div className="border-b border-[#F0F0ED] pb-8">
            <h2 className="font-display font-bold text-[36px] sm:text-[44px] text-[#111111] leading-none tracking-tight">
              {siteMeta.name}
            </h2>
            <p className="font-sans text-[13px] sm:text-[14px] uppercase tracking-wider text-[#8A8A87] mt-2 font-bold">
              {siteMeta.role} — 5+ Years Experience
            </p>
            <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2 font-sans text-[13px] text-[#575757]">
              <span>{siteMeta.email}</span>
              <span>{siteMeta.location}</span>
              <a
                href={siteMeta.linkedinUrl}
                target="_blank"
                rel="noreferrer"
                className="text-[#111111] underline font-semibold hover:text-black transition-colors"
              >
                LinkedIn Profile
              </a>
            </div>
            <p className="mt-4 text-[15px] sm:text-[16px] leading-relaxed text-[#575757] max-w-[680px] font-sans">
              “I get uncomfortably close to complex problems until they become simple, loveable, usable and comfortable experiences.”
            </p>
          </div>

          {/* Capabilities */}
          <div>
            <span className="font-sans text-[11px] uppercase tracking-[0.14em] text-[#8A8A87] block mb-3 font-bold">
              CORE PRACTICE
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-sans text-[13px]">
              <div className="p-3 rounded-xl bg-[#F7F7F7] border border-[#E5E5E2] text-[#111111] font-semibold">Product Design</div>
              <div className="p-3 rounded-xl bg-[#F7F7F7] border border-[#E5E5E2] text-[#111111] font-semibold">UX Design</div>
              <div className="p-3 rounded-xl bg-[#F7F7F7] border border-[#E5E5E2] text-[#111111] font-semibold">Design Systems</div>
              <div className="p-3 rounded-xl bg-[#F7F7F7] border border-[#E5E5E2] text-[#111111] font-semibold">Complex Workflows / AI</div>
            </div>
          </div>

          {/* Experience Progression */}
          <div>
            <span className="font-sans text-[11px] uppercase tracking-[0.14em] text-[#8A8A87] block mb-4 font-bold">
              EXPERIENCE TIMELINE
            </span>
            <div className="space-y-6 divide-y divide-[#F0F0ED]">
              {experienceData.map((item) => (
                <div key={item.id} className="pt-6 first:pt-0">
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                    <h3 className="text-[17px] font-bold text-[#111111] font-sans">
                      {item.role} <span className="font-normal text-[#8A8A87]">at {item.company}</span>
                    </h3>
                    <span className="font-sans text-[12px] text-[#8A8A87] shrink-0 font-medium">
                      {item.dates} — {item.location}
                    </span>
                  </div>
                  {item.description && (
                    <p className="text-[14px] text-[#575757] mt-2 leading-relaxed font-sans">
                      {item.description}
                    </p>
                  )}
                  {item.highlightMetric && (
                    <p className="font-sans text-[12px] uppercase tracking-wider text-[#111111] mt-2 font-bold">
                      ★ {item.highlightMetric}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Selected Work & Clients */}
          <div className="border-t border-[#F0F0ED] pt-6">
            <span className="font-sans text-[11px] uppercase tracking-[0.14em] text-[#8A8A87] block mb-2 font-bold">
              SELECTED CLIENT WORK
            </span>
            <p className="text-[14px] text-[#575757] leading-relaxed font-sans">
              <strong className="text-[#111111]">Unilever (Indulekha)</strong> — Brand & Experience Redesign <br />
              <strong className="text-[#111111]">Tech Mahindra</strong> — LineSense Automation & Industrial Telemetry UX <br />
              <strong className="text-[#111111]">Typeface</strong> — Generative AI Product Design for Enterprise Workflows <br />
              <strong className="text-[#111111]">Reclaimz</strong> — Healthcare Claims Management UX
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
