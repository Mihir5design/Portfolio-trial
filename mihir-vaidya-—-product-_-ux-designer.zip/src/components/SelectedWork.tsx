import React, { useState } from 'react';
import { ArrowUpRight, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { projectsData } from '../data/portfolioData';
import { GridPulse } from './ui/grid-pulse';

interface SelectedWorkProps {
  onSelectProject: (slug: string) => void;
}

export const SelectedWork: React.FC<SelectedWorkProps> = ({ onSelectProject }) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');

  // Compact horizontal artwork showcases
  const projectThumbnails: Record<string, React.ReactNode> = {
    typeface: (
      <div className="w-full h-full min-h-[100px] sm:min-h-[150px] rounded-xl bg-gradient-to-br from-[#0B0F19] via-[#1E293B] to-[#0F766E] p-3 relative overflow-hidden flex items-center justify-center select-none group-hover:scale-[1.02] transition-transform duration-300">
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#F59E0B_1px,transparent_1px)] [background-size:10px_10px]" />
        <div className="absolute -left-4 top-4 w-40 h-4 bg-[#FBBF24] -rotate-45 shadow-md opacity-90 rounded-full" />
        <div className="relative z-10 px-3 py-1.5 rounded-lg bg-white/10 backdrop-blur-md border border-white/20 text-white font-mono text-[10px] font-bold tracking-wider flex items-center gap-1.5 shadow-md">
          <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
          <span>GENAI CANVAS</span>
        </div>
      </div>
    ),
    healthco: (
      <div className="w-full h-full min-h-[100px] sm:min-h-[150px] rounded-xl bg-gradient-to-br from-[#F5F3FF] via-[#EDE9FE] to-[#DDD6FE] p-3 relative overflow-hidden flex items-center justify-center select-none group-hover:scale-[1.02] transition-transform duration-300">
        <div className="absolute -bottom-6 -left-6 w-24 h-24 rounded-full bg-gradient-to-tr from-[#8B5CF6] to-[#C4B5FD] shadow-md opacity-75" />
        <div className="relative z-10 px-3.5 py-1.5 rounded-full bg-white/95 backdrop-blur-md border border-white shadow-xs rotate-[-2deg] flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-[#8B5CF6]" />
          <span className="font-mono text-[10px] font-bold text-[#7C3AED]">
            50 SEC INTAKE
          </span>
        </div>
      </div>
    ),
    indulekha: (
      <div className="w-full h-full min-h-[100px] sm:min-h-[150px] rounded-xl bg-[#141210] p-3 relative overflow-hidden flex items-center justify-center select-none group-hover:scale-[1.02] transition-transform duration-300">
        <div className="absolute inset-0 bg-[radial-gradient(#F59E0B_1px,transparent_1px)] [background-size:10px_10px] opacity-25" />
        <div className="relative z-10 flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D97706] to-[#78350F] shadow-sm rotate-6 border border-[#FDE68A]/30 flex items-center justify-center">
            <span className="font-mono text-white text-[9px] font-bold">DOSHA</span>
          </div>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#F59E0B] to-[#92400E] shadow-xs -rotate-6 border border-[#FDE68A]/20 flex items-center justify-center">
            <span className="font-mono text-white text-[9px] font-bold">DIAG</span>
          </div>
        </div>
      </div>
    ),
    linesense: (
      <div className="w-full h-full min-h-[100px] sm:min-h-[150px] rounded-xl bg-gradient-to-br from-[#FFF7ED] via-[#FFEDD5] to-[#FED7AA] p-3 relative overflow-hidden flex items-center justify-center select-none group-hover:scale-[1.02] transition-transform duration-300">
        <div className="relative z-10 flex flex-col items-center gap-1">
          <div className="px-2.5 py-1 rounded-full bg-gradient-to-r from-[#FB923C] to-[#F97316] text-white font-mono text-[8.5px] font-bold shadow-xs">
            ACOUSTIC AI
          </div>
          <div className="w-16 h-3 rounded-full bg-[#FED7AA]" />
        </div>
      </div>
    ),
  };

  const projectMeta: Record<
    string,
    {
      domain: string;
      metric: string;
      filterTag: string;
      hook: string;
      tags: string[];
    }
  > = {
    typeface: {
      domain: 'AI · ENTERPRISE',
      metric: '4 workflows → 1 canvas',
      filterTag: 'ai',
      hook: 'GenAI multimodal canvas for enterprise campaign generation.',
      tags: ['Multimodal AI', 'Canvas Tooling'],
    },
    healthco: {
      domain: 'HEALTHCARE TECH',
      metric: '8m → 50s intake',
      filterTag: 'health',
      hook: 'Digital patient intake and medical extraction system.',
      tags: ['Healthcare UX', 'Doc Extraction'],
    },
    indulekha: {
      domain: 'CONSUMER · COMMERCE',
      metric: '+15% lead conversion',
      filterTag: 'consumer',
      hook: 'Ayurvedic hair diagnosis consultation with personalisation.',
      tags: ['D2C Diagnostic', 'E-Commerce'],
    },
    linesense: {
      domain: 'MANUFACTURING · AI',
      metric: '62% faster setup',
      filterTag: 'ai',
      hook: 'Acoustic inspection platform reducing machine calibration cycles.',
      tags: ['Industrial AI', 'Telemetry'],
    },
  };

  const allProjects = projectsData.slice(0, 4);

  const filteredProjects =
    activeFilter === 'all'
      ? allProjects
      : allProjects.filter((p) => {
          const meta = projectMeta[p.slug];
          return meta && meta.filterTag === activeFilter;
        });

  return (
    <section
      id="work"
      className="relative w-full min-h-screen lg:h-screen lg:max-h-[1080px] md:snap-start bg-white dark:bg-[#18181b] select-none overflow-visible lg:overflow-hidden flex flex-col justify-center pt-24 sm:pt-28 lg:py-16 pb-12 sm:pb-14 transition-colors duration-250"
    >
      {/* Dynamic Grid Pulse ambient interactive background */}
      <GridPulse
        cell={32}
        reach={2.4}
        ambient={1}
        maxLit={65}
        avoid="[data-grid-avoid]"
        className="opacity-45 pointer-events-none"
      />

      <div className="relative z-10 max-w-[1360px] w-full mx-auto px-4 sm:px-8 lg:px-12 flex flex-col justify-between h-auto lg:h-full min-h-full lg:max-h-[920px]">
        {/* Compact Header with integrated filters */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 sm:mb-6 shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#8fc33b]" />
              <span className="font-mono text-[10.5px] uppercase tracking-[0.14em] font-bold text-[#8A8A87] dark:text-[#A1A1AA]">
                SELECTED WORK
              </span>
            </div>
            <h2
              data-grid-avoid
              className="font-display font-bold text-[24px] sm:text-[32px] lg:text-[36px] tracking-tight text-[#111111] dark:text-white leading-tight"
            >
              Problems I've enjoyed solving.
            </h2>
          </div>

          {/* Clean Category Filter Buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { key: 'all', label: 'All Work' },
              { key: 'ai', label: 'AI & Enterprise' },
              { key: 'health', label: 'Healthcare' },
              { key: 'consumer', label: 'Consumer D2C' },
            ].map((f) => (
              <button
                key={f.key}
                type="button"
                onClick={() => setActiveFilter(f.key)}
                className={`px-3 py-1.5 rounded-full font-sans text-[11.5px] font-bold tracking-tight transition-all cursor-pointer ${
                  activeFilter === f.key
                    ? 'bg-[#111111] dark:bg-white text-white dark:text-[#111111] shadow-xs'
                    : 'bg-[#F4F4F2] dark:bg-[#27272a] text-[#666666] dark:text-[#A1A1AA] hover:text-[#111111] dark:hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Viewport-Optimized Horizontal Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 sm:gap-4 lg:gap-5 flex-1 items-stretch my-0 lg:my-auto">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, idx) => {
              const meta = projectMeta[project.slug] || {
                domain: project.category,
                metric: project.outcome.slice(0, 20),
                filterTag: 'other',
                hook: project.shortDescription,
                tags: ['Product Design'],
              };

              return (
                <motion.article
                  key={project.id}
                  id={`project-card-${project.slug}`}
                  layout
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  transition={{ duration: 0.35, delay: idx * 0.04 }}
                  onClick={() => onSelectProject(project.slug)}
                  className="group rounded-[20px] sm:rounded-[24px] border border-[#E8E8E5] dark:border-[#2e2e34] hover:border-[#111111] dark:hover:border-[#8fc33b] bg-white dark:bg-[#202126] p-3 sm:p-4.5 flex flex-col sm:flex-row items-stretch gap-3 sm:gap-4 transition-all duration-300 hover:shadow-[0_16px_36px_-12px_rgba(0,0,0,0.18)] cursor-pointer relative overflow-hidden"
                >
                  {/* Left Column: Horizontal Visual Artwork Tile */}
                  <div className="w-full sm:w-[150px] lg:w-[180px] h-[105px] xs:h-[120px] sm:h-auto shrink-0 rounded-xl overflow-hidden relative flex items-center justify-center">
                    {projectThumbnails[project.slug]}
                  </div>

                  {/* Right Column: Content & Metadata */}
                  <div className="flex-1 flex flex-col justify-between min-w-0">
                    <div>
                      {/* Domain & Outcome Metric Pill */}
                      <div className="flex items-center justify-between font-mono text-[10px] text-[#737373] dark:text-[#A1A1AA] mb-1.5">
                        <span className="font-bold tracking-wider uppercase text-[#111111] dark:text-neutral-200 truncate pr-2">
                          {meta.domain}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-[#F5F5F3] dark:bg-[#292a30] text-[#111111] dark:text-white font-mono text-[9.5px] font-bold border border-[#E5E5E2] dark:border-[#3a3b42] shrink-0">
                          {meta.metric}
                        </span>
                      </div>

                      {/* Project Title */}
                      <h3 className="font-display font-bold text-[18px] sm:text-[20px] lg:text-[22px] tracking-tight text-[#111111] dark:text-white leading-snug flex items-center justify-between">
                        <span className="truncate">{project.title}</span>
                        <ArrowUpRight className="w-4 h-4 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all text-[#111111] dark:text-white shrink-0 ml-1.5" />
                      </h3>

                      {/* Compact Hook */}
                      <p className="font-sans text-[12.5px] sm:text-[13px] text-[#555555] dark:text-[#A1A1AA] mt-1 line-clamp-2 leading-relaxed">
                        {meta.hook}
                      </p>

                      {/* Deliverable Tags */}
                      <div className="flex flex-wrap gap-1 mt-2.5">
                        {meta.tags.map((tag) => (
                          <span
                            key={tag}
                            className="px-2 py-0.5 rounded-md bg-[#F7F7F6] dark:bg-[#27272a] text-[#666666] dark:text-neutral-300 font-mono text-[9.5px] tracking-wide"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Bottom CTA Row: Bold */}
                    <div className="pt-2.5 mt-2 border-t border-[#F0F0ED] dark:border-[#2e2e34] flex items-center justify-between font-sans">
                      <span className="font-bold uppercase tracking-wider text-[#111111] dark:text-white text-[11px] inline-flex items-center gap-1.5 group-hover:translate-x-0.5 transition-transform">
                        <span className="font-bold">Read Case Study</span>
                        <ArrowRight className="w-3 h-3 stroke-[2.5]" />
                      </span>
                    </div>
                  </div>
                </motion.article>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};
