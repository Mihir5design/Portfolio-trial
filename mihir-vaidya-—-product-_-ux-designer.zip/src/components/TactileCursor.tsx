import React, { useEffect, useState } from 'react';

export const TactileCursor: React.FC = () => {
  const [targetPos, setTargetPos] = useState({ x: -100, y: -100 });
  const [followerPos, setFollowerPos] = useState({ x: -100, y: -100 });
  const [isHoveringClickable, setIsHoveringClickable] = useState(false);
  const [isMouseDown, setIsMouseDown] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Detect touch
    const isTouch = window.matchMedia('(pointer: coarse)').matches;
    setIsTouchDevice(isTouch);
    if (isTouch) return;

    const handleMouseMove = (e: MouseEvent) => {
      setTargetPos({ x: e.clientX, y: e.clientY });
      if (!isVisible) setIsVisible(true);

      const target = e.target as HTMLElement | null;
      if (target) {
        const isClickable = Boolean(
          target.closest('button, a, input, textarea, [role="button"], .cursor-pointer, [data-cursor="pointer"]')
        );
        setIsHoveringClickable(isClickable);
      }
    };

    const handleMouseDown = () => setIsMouseDown(true);
    const handleMouseUp = () => setIsMouseDown(false);
    const handleMouseLeave = () => setIsVisible(false);
    const handleMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [isVisible]);

  // Smooth lerp for outer fluid follower
  useEffect(() => {
    if (isTouchDevice) return;

    let animFrameId: number;
    const lerp = (start: number, end: number, factor: number) => start + (end - start) * factor;

    const animate = () => {
      setFollowerPos((prev) => ({
        x: lerp(prev.x, targetPos.x, 0.16),
        y: lerp(prev.y, targetPos.y, 0.16),
      }));
      animFrameId = requestAnimationFrame(animate);
    };

    animFrameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animFrameId);
  }, [targetPos, isTouchDevice]);

  if (isTouchDevice || !isVisible) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[9999] overflow-hidden">
      {/* 1. Fluid Lag Trailing Halo */}
      <div
        className="fixed top-0 left-0 -translate-x-1/2 -translate-y-1/2 rounded-full transition-[width,height,transform] duration-150 ease-out will-change-transform"
        style={{
          transform: `translate3d(${followerPos.x}px, ${followerPos.y}px, 0) scale(${
            isMouseDown ? 0.85 : 1
          })`,
          width: isHoveringClickable ? '38px' : '26px',
          height: isHoveringClickable ? '38px' : '26px',
          border: '1.5px solid rgba(143, 195, 59, 0.65)',
          backgroundColor: isHoveringClickable
            ? 'rgba(143, 195, 59, 0.08)'
            : 'transparent',
        }}
      />

      {/* 2. Precision Designer Lime Arrow Cursor (Always visible) */}
      <div
        className="fixed top-0 left-0 -translate-x-1 -translate-y-1 will-change-transform transition-transform duration-75"
        style={{
          transform: `translate3d(${targetPos.x}px, ${targetPos.y}px, 0) scale(${
            isMouseDown ? 0.9 : 1
          })`,
        }}
      >
        <svg
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          className="drop-shadow-[0_1px_3px_rgba(0,0,0,0.35)]"
        >
          <path
            d="M3 3L10.07 20.97L13.58 13.58L20.97 10.07L3 3Z"
            fill="#8fc33b"
            stroke="#111111"
            strokeWidth="1.5"
            strokeLinejoin="round"
          />
        </svg>
      </div>
    </div>
  );
};
