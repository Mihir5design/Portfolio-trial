import React from 'react';
import { ArrowUpRight, Mail, Linkedin, MessageCircle } from 'lucide-react';
import { siteMeta } from '../data/portfolioData';
import { MihirLogo } from './MihirLogo';
import { GridPulse } from './ui/grid-pulse';

interface FinalCTAProps {
  onGetInTouch: () => void;
  onScrollToTop: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onScrollToTop }) => {
  const currentYear = new Date().getFullYear();

  const handleScrollTop = (e: React.MouseEvent) => {
    e.preventDefault();
    onScrollToTop();
  };

  return (
    <section
      id="contact"
      className="relative w-full min-h-screen lg:h-screen lg:max-h-[1080px] snap-start bg-white dark:bg-[#18181b] select-none flex flex-col justify-between pt-24 sm:pt-28 lg:pt-32 pb-6 sm:pb-8 transition-colors duration-250 overflow-hidden"
    >
      {/* Dynamic Grid Pulse ambient interactive background */}
      <GridPulse
        cell={32}
        reach={2.4}
        ambient={1}
        maxLit={45}
        avoid="[data-grid-avoid]"
        className="opacity-40 pointer-events-none"
      />

      <div className="relative z-10 max-w-[1360px] w-full mx-auto px-6 sm:px-10 lg:px-12 flex flex-col justify-between h-full max-h-[820px] my-auto">
        {/* Top Contact Channels Row - Padded safely beneath the floating navbar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 items-center">
          <div className="lg:col-span-6">
            <div className="inline-flex items-center gap-2 mb-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#8fc33b]" />
              <span className="font-mono text-[11px] sm:text-[12px] uppercase tracking-[0.14em] font-bold text-[#8A8A87] dark:text-[#A1A1AA]">
                GET IN TOUCH
              </span>
            </div>

            <h2
              data-grid-avoid
              className="font-display font-bold text-[30px] sm:text-[40px] lg:text-[46px] leading-[1.08] tracking-tight text-[#111111] dark:text-white"
            >
              Start a conversation.
            </h2>
            <p
              data-grid-avoid
              className="text-[14px] sm:text-[15.5px] text-[#555555] dark:text-[#A1A1AA] font-sans leading-relaxed max-w-[460px] mt-2"
            >
              Tell me what you're building, changing, or trying to understand. Pick the channel that feels easiest.
            </p>
          </div>

          {/* Right Column: Sleek Direct Channels with Bold Text */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <div className="space-y-2.5 w-full max-w-[480px] lg:ml-auto">
              {/* Email */}
              <a
                href={`mailto:${siteMeta.email}`}
                className="group flex items-center justify-between p-3 sm:p-3.5 rounded-2xl border border-[#E5E5E2] dark:border-[#2e2e34] bg-white dark:bg-[#202126] hover:bg-[#111111] dark:hover:bg-white text-[#111111] dark:text-white hover:text-white dark:hover:text-black transition-all duration-200 cursor-pointer shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8.5 h-8.5 rounded-xl bg-[#F4F4F2] dark:bg-[#292a30] group-hover:bg-white/10 dark:group-hover:bg-black/10 flex items-center justify-center transition-colors">
                    <Mail className="w-4 h-4 text-[#111111] dark:text-white group-hover:text-white dark:group-hover:text-black" />
                  </div>
                  <div>
                    <span className="font-mono text-[9px] text-[#8A8A87] dark:text-neutral-400 group-hover:text-white/70 dark:group-hover:text-black/70 block uppercase font-bold">
                      EMAIL
                    </span>
                    <span className="font-sans text-[13.5px] sm:text-[14px] font-bold">
                      {siteMeta.email}
                    </span>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#8A8A87] group-hover:text-white dark:group-hover:text-black group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>

              {/* LinkedIn */}
              <a
                href={siteMeta.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center justify-between p-3 sm:p-3.5 rounded-2xl border border-[#E5E5E2] dark:border-[#2e2e34] bg-white dark:bg-[#202126] hover:bg-[#111111] dark:hover:bg-white text-[#111111] dark:text-white hover:text-white dark:hover:text-black transition-all duration-200 cursor-pointer shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8.5 h-8.5 rounded-xl bg-[#F4F4F2] dark:bg-[#292a30] group-hover:bg-white/10 dark:group-hover:bg-black/10 flex items-center justify-center transition-colors">
                    <Linkedin className="w-4 h-4 text-[#111111] dark:text-white group-hover:text-white dark:group-hover:text-black" />
                  </div>
                  <div>
                    <span className="font-mono text-[9px] text-[#8A8A87] dark:text-neutral-400 group-hover:text-white/70 dark:group-hover:text-black/70 block uppercase font-bold">
                      LINKEDIN
                    </span>
                    <span className="font-sans text-[13.5px] sm:text-[14px] font-bold">
                      Connect professionally
                    </span>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#8A8A87] group-hover:text-white dark:group-hover:text-black group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>

              {/* WhatsApp */}
              <a
                href={siteMeta.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center justify-between p-3 sm:p-3.5 rounded-2xl border border-[#E5E5E2] dark:border-[#2e2e34] bg-white dark:bg-[#202126] hover:bg-[#111111] dark:hover:bg-white text-[#111111] dark:text-white hover:text-white dark:hover:text-black transition-all duration-200 cursor-pointer shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8.5 h-8.5 rounded-xl bg-[#F4F4F2] dark:bg-[#292a30] group-hover:bg-white/10 dark:group-hover:bg-black/10 flex items-center justify-center transition-colors">
                    <MessageCircle className="w-4 h-4 text-[#111111] dark:text-white group-hover:text-white dark:group-hover:text-black" />
                  </div>
                  <div>
                    <span className="font-mono text-[9px] text-[#8A8A87] dark:text-neutral-400 group-hover:text-white/70 dark:group-hover:text-black/70 block uppercase font-bold">
                      WHATSAPP
                    </span>
                    <span className="font-sans text-[13.5px] sm:text-[14px] font-bold">
                      Start a quick chat
                    </span>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#8A8A87] group-hover:text-white dark:group-hover:text-black group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Footer Card with Mesh Grainy Gradient */}
        <div className="relative rounded-[22px] sm:rounded-[28px] p-5 sm:p-7 lg:p-8 shadow-2xl overflow-hidden border border-white/10 text-white mt-4 sm:mt-6">
          {/* Mesh Grainy Gradient Background */}
          <div
            className="absolute inset-0 z-0 pointer-events-none"
            style={{
              backgroundColor: '#16171d',
              backgroundImage: `
                radial-gradient(at 15% 15%, rgba(67, 56, 202, 0.45) 0px, transparent 55%),
                radial-gradient(at 85% 20%, rgba(143, 195, 59, 0.3) 0px, transparent 50%),
                radial-gradient(at 50% 90%, rgba(15, 23, 42, 0.8) 0px, transparent 65%),
                radial-gradient(at 75% 85%, rgba(88, 28, 135, 0.4) 0px, transparent 55%),
                radial-gradient(at 20% 80%, rgba(20, 184, 166, 0.25) 0px, transparent 50%)
              `,
            }}
          />

          {/* Grain Noise Overlay using SVG filter */}
          <svg className="absolute inset-0 w-full h-full opacity-35 mix-blend-overlay pointer-events-none z-0">
            <filter id="mesh-grain">
              <feTurbulence
                type="fractalNoise"
                baseFrequency="0.8"
                numOctaves="4"
                stitchTiles="stitch"
              />
              <feColorMatrix type="saturate" values="0" />
            </filter>
            <rect width="100%" height="100%" filter="url(#mesh-grain)" />
          </svg>

          {/* Footer Card Content */}
          <div className="relative z-10">
            <div className="flex items-center justify-between font-mono text-[10px] sm:text-[10.5px] text-[#A1A1AA] tracking-widest uppercase pb-2.5 border-b border-white/15">
              <span className="font-bold">PRODUCT DESIGNER · INDORE, INDIA</span>
              <button
                type="button"
                onClick={handleScrollTop}
                className="hover:text-white flex items-center gap-1.5 cursor-pointer transition-colors font-bold"
              >
                <span>BACK TO TOP</span>
                <ArrowUpRight className="w-3.5 h-3.5 stroke-[2.5]" />
              </button>
            </div>

            {/* Logo */}
            <div className="py-3 sm:py-4">
              <MihirLogo
                variant="dark"
                size={40}
                wordmarkClassName="font-display font-bold text-[28px] sm:text-[38px] lg:text-[44px] tracking-[-0.03em] text-white leading-none"
              />
            </div>

            {/* Bottom Bar with Bold CTAs */}
            <div className="pt-2.5 border-t border-white/15 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 font-mono text-[10px] sm:text-[10.5px] text-[#A1A1AA]">
              <div>© {currentYear} Mihir Vaidya. All rights reserved.</div>
              <div className="flex items-center gap-4 sm:gap-5 text-white">
                <a href={`mailto:${siteMeta.email}`} className="hover:text-[#8fc33b] font-bold transition-colors">Email</a>
                <a href={siteMeta.linkedinUrl} target="_blank" rel="noopener noreferrer" className="hover:text-[#8fc33b] font-bold transition-colors">LinkedIn</a>
                <a href={siteMeta.whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-[#8fc33b] font-bold transition-colors">WhatsApp</a>
              </div>
              <div className="hidden md:block text-[#9CA3AF]">
                Designed for clarity, not decoration.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
