import React from 'react';
import { ArrowUpRight, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { GridPulse } from './ui/grid-pulse';

interface AboutSnapshotProps {
  onNavigateAbout: () => void;
  onContactClick?: () => void;
}

export const AboutSnapshot: React.FC<AboutSnapshotProps> = ({
  onNavigateAbout,
  onContactClick,
}) => {
  return (
    <section
      id="about"
      className="relative w-full min-h-screen lg:h-screen lg:max-h-[1080px] snap-start bg-white dark:bg-[#18181b] select-none overflow-hidden flex flex-col justify-center pt-24 sm:pt-28 pb-12 sm:pb-16 transition-colors duration-250"
    >
      {/* Dynamic Grid Pulse ambient interactive background */}
      <GridPulse
        cell={32}
        reach={2.4}
        ambient={1}
        maxLit={50}
        avoid="[data-grid-avoid]"
        className="opacity-45 pointer-events-none"
      />

      <div className="relative z-10 max-w-[1360px] w-full mx-auto px-6 sm:px-10 lg:px-12 flex flex-col justify-between h-full max-h-[820px]">
        {/* Center Grid: Tilted Specimen Tablet on Left, Bio on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center my-auto">
          {/* Left Column: Tilted Specimen Tablet */}
          <div className="lg:col-span-5 flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.94, rotate: -3 }}
              whileInView={{ opacity: 1, scale: 1, rotate: -3 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              data-grid-avoid
              className="relative w-[260px] sm:w-[300px] md:w-[320px] aspect-[1/1.2] rounded-[30px] sm:rounded-[34px] bg-[#FBFBFA] dark:bg-[#202126] border border-[#E8E8E5] dark:border-[#2e2e34] shadow-[0_24px_54px_-16px_rgba(0,0,0,0.1)] p-6 sm:p-7 flex flex-col justify-between select-none hover:rotate-[-1deg] transition-transform duration-500"
            >
              {/* Top Row: Experience badge */}
              <div className="flex items-center justify-between font-mono text-[10px] sm:text-[11px] text-[#8A8A87] dark:text-[#A1A1AA] tracking-widest uppercase">
                <span>PRACTICE</span>
                <span className="font-bold text-[#111111] dark:text-white">5+ YEARS EXPERIENCE</span>
              </div>

              {/* Graphic: Fine Compass Circle with Lime Accent Dot */}
              <div className="relative mx-auto my-1 w-20 h-20 sm:w-24 sm:h-24 rounded-full border border-[#E5E5E2] dark:border-[#3a3b42] flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-[#8fc33b] absolute top-2 right-3 shadow-sm" />
                <div className="w-1.5 h-1.5 rounded-full bg-[#111111] dark:bg-white" />
              </div>

              {/* Centered MAKE / SENSE Graphic */}
              <div className="text-center my-auto py-1">
                <div className="font-display font-bold text-[38px] sm:text-[46px] text-[#8fc33b] tracking-[-0.035em] leading-[0.88]">
                  MAKE
                </div>
                <div className="font-display font-bold text-[38px] sm:text-[46px] text-[#111111] dark:text-white tracking-[-0.035em] leading-[0.88]">
                  SENSE.
                </div>
              </div>

              {/* Bottom Sticker Pill */}
              <div className="pt-2 flex items-center justify-center">
                <span className="px-3.5 py-1 rounded-full border border-[#E5E5E2] dark:border-[#3a3b42] bg-white dark:bg-[#292a30] font-mono text-[10px] sm:text-[11px] font-bold text-[#111111] dark:text-neutral-200 tracking-wider">
                  Curious by default.
                </span>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Bio Copy */}
          <div className="lg:col-span-7">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              data-grid-avoid
              className="font-display font-bold text-[28px] sm:text-[36px] lg:text-[42px] xl:text-[48px] tracking-tight text-[#111111] dark:text-white leading-[1.06] mb-4 sm:mb-5"
            >
              Part designer. Part
              <br />
              problem investigator.
              <br />
              Part professional
              <br />
              overthinker.
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.15 }}
              data-grid-avoid
              className="text-[14.5px] sm:text-[16px] lg:text-[17px] text-[#525252] dark:text-[#A1A1AA] font-sans leading-[1.65] max-w-[560px] mb-5 sm:mb-6"
            >
              I've spent 5+ years designing products across B2B, healthcare, fintech, AI, and enterprise. The industry changes; the enjoyable part stays the same: getting into the details, finding the real problem, and making it intuitive to use.
            </motion.p>

            {/* Status Pills */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.25 }}
              className="flex flex-wrap items-center gap-3 font-sans text-[12px] sm:text-[13px] font-bold text-[#111111] dark:text-white"
            >
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#E5E5E2] dark:border-[#3a3b42] bg-[#F7F7F7] dark:bg-[#202126]">
                <MapPin className="w-3.5 h-3.5 text-[#111111] dark:text-white" />
                <span>Indore, India</span>
              </div>

              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#E5E5E2] dark:border-[#3a3b42] bg-[#F7F7F7] dark:bg-[#202126]">
                <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
                <span>Open to select collaborations</span>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Bottom Experience Strip with Bold CTA */}
        <div className="pt-4 border-t border-[#EAEAE8] dark:border-[#2e2e34]">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center font-sans text-[12.5px] sm:text-[13.5px]">
            {/* Experience */}
            <div className="md:col-span-5 flex items-center gap-2">
              <span className="font-mono text-[9.5px] text-[#8A8A87] dark:text-[#A1A1AA] uppercase tracking-wider font-bold">
                EXPERIENCE:
              </span>
              <span className="font-bold text-[#111111] dark:text-white">F1 Studioz</span>
              <span className="text-[#737373] dark:text-[#A1A1AA]">/ UX Designer · 2022 — 2025</span>
            </div>

            {/* Also worked with */}
            <div className="md:col-span-5 flex items-center gap-2">
              <span className="font-mono text-[9.5px] text-[#8A8A87] dark:text-[#A1A1AA] uppercase tracking-wider font-bold">
                ALSO WORKED WITH:
              </span>
              <span className="font-bold text-[#333333] dark:text-neutral-300">
                7Edge · Siya Tech · Credence
              </span>
            </div>

            {/* Say hello button */}
            <div className="md:col-span-2 flex md:justify-end">
              <button
                type="button"
                onClick={onContactClick || onNavigateAbout}
                className="font-bold text-[#111111] dark:text-white hover:text-[#8fc33b] dark:hover:text-[#8fc33b] flex items-center gap-1 group cursor-pointer"
              >
                <span className="font-bold">Say hello</span>
                <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform stroke-[2.5]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
