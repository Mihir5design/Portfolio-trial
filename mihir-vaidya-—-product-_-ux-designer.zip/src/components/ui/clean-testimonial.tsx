import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, ChevronRight, Quote, Star, CheckCircle2 } from "lucide-react";
import { GridPulse } from "./grid-pulse";

export interface TestimonialItem {
  quote: string;
  name: string;
  role: string;
  company: string;
  avatar?: string;
  rating?: number;
  highlight?: string;
}

const DEFAULT_TESTIMONIALS: TestimonialItem[] = [
  {
    quote:
      "Mihir brings extraordinary structural clarity to complex workflows. He bridged our AI engine with real enterprise campaign workflows faster and cleaner than anyone on our team expected.",
    name: "Nikhil Joshi",
    role: "VP of Product",
    company: "Typeface / Enterprise AI",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80",
    rating: 5,
    highlight: "Bridges design & engineering seamlessly",
  },
  {
    quote:
      "Mihir takes deep ownership of the problem space. He does not stop at making things look polished—he ensures the workflow genuinely solves the user's real need.",
    name: "Bhushan Pungliya",
    role: "Product Director",
    company: "Healthcare Solutions",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=160&auto=format&fit=crop&q=80",
    rating: 5,
    highlight: "Deep ownership of the problem space",
  },
  {
    quote:
      "Mihir's work had an immediate, measurable impact on user engagement and conversion. He understands how design drives actual business outcomes beyond the screen.",
    name: "Mahak Jain",
    role: "Growth & Strategy",
    company: "Consumer Tech",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=160&auto=format&fit=crop&q=80",
    rating: 5,
    highlight: "Measurable impact on conversion & engagement",
  },
  {
    quote:
      "His methodical approach to problem-solving and willingness to question assumptions made a massive difference across our complex enterprise product initiatives.",
    name: "Vedanth",
    role: "UX Lead",
    company: "Design Systems",
    avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=160&auto=format&fit=crop&q=80",
    rating: 5,
    highlight: "Methodical problem-solving & clarity",
  },
];

export function Testimonial({
  testimonials = DEFAULT_TESTIMONIALS,
  title = "What people say when I'm not in the room.",
  eyebrow = "RECOMMENDATIONS",
  autoPlay = false,
  interval = 7000,
}: {
  testimonials?: TestimonialItem[];
  title?: string;
  eyebrow?: string;
  autoPlay?: boolean;
  interval?: number;
}) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const activeItem = testimonials[currentIndex] || testimonials[0];

  useEffect(() => {
    if (!autoPlay) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, interval);
    return () => clearInterval(timer);
  }, [autoPlay, interval, testimonials.length]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  return (
    <section
      id="testimonials"
      className="relative w-full min-h-screen lg:h-screen lg:max-h-[1080px] snap-start bg-white dark:bg-[#18181b] text-[#111111] dark:text-[#F3F4F6] overflow-hidden select-none flex flex-col justify-center pt-24 sm:pt-28 pb-12 sm:pb-16 transition-colors duration-250"
    >
      {/* Dynamic Grid Pulse ambient interactive background */}
      <GridPulse
        cell={32}
        reach={2.4}
        ambient={1}
        maxLit={50}
        avoid="[data-grid-avoid]"
        className="opacity-45 pointer-events-none"
      />

      <div className="relative z-10 max-w-[1100px] w-full mx-auto px-6 sm:px-10 lg:px-12 flex flex-col justify-between h-full max-h-[780px]">
        {/* Centered Heading without subtext or separation line */}
        <div className="text-center mx-auto max-w-[800px] mb-8 sm:mb-10">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-1.5 h-1.5 rounded-full bg-[#8fc33b]" />
            <span className="font-mono text-[11px] sm:text-[12px] uppercase tracking-[0.14em] font-bold text-[#8A8A87] dark:text-[#A1A1AA]">
              {eyebrow}
            </span>
          </div>
          <h2
            data-grid-avoid
            className="font-display font-bold text-[30px] sm:text-[40px] lg:text-[46px] leading-[1.08] tracking-tight text-[#111111] dark:text-white"
          >
            {title}
          </h2>
        </div>

        {/* Featured Testimonial Content (No card background, pure typographic elegance) */}
        <div className="w-full max-w-[880px] mx-auto my-auto px-2 sm:px-6 py-4 flex flex-col justify-between relative">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="flex flex-col items-center text-center justify-between"
            >
              {/* Header Icon + Rating */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 mb-6">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#F4F4F2] dark:bg-[#27282e] border border-[#E5E5E2] dark:border-[#383940] flex items-center justify-center text-[#111111] dark:text-white shadow-2xs shrink-0">
                  <Quote className="w-4 h-4 text-[#111111] dark:text-white" />
                </div>
                <div className="flex items-center gap-1 text-[#8fc33b]">
                  {[...Array(activeItem.rating || 5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-[#8fc33b] text-[#8fc33b]" />
                  ))}
                  <span className="font-mono text-[10.5px] text-[#111111] dark:text-white font-bold ml-2 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-[#8fc33b]" /> Verified
                  </span>
                </div>
              </div>

              {/* Quote Text */}
              <blockquote
                data-grid-avoid
                className="font-display font-medium text-[22px] sm:text-[28px] lg:text-[32px] leading-[1.3] tracking-tight text-[#111111] dark:text-white mb-8 text-center max-w-[820px] mx-auto"
              >
                “{activeItem.quote}”
              </blockquote>

              {/* Author Meta */}
              <div className="flex flex-col items-center justify-center gap-2.5 pt-5 border-t border-[#EAEAE8] dark:border-[#2e2e34] w-full max-w-[360px] mx-auto text-center">
                {activeItem.avatar ? (
                  <img
                    src={activeItem.avatar}
                    alt={activeItem.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full object-cover border border-[#E5E5E2] dark:border-[#3a3b42] shadow-xs"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-[#111111] dark:bg-white text-white dark:text-black font-bold flex items-center justify-center font-display text-xs">
                    {activeItem.name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                <div className="flex flex-col items-center text-center">
                  <div className="font-display font-bold text-[16px] text-[#111111] dark:text-white leading-tight">
                    {activeItem.name}
                  </div>
                  <div className="font-sans text-[13px] text-[#737373] dark:text-[#A1A1AA] mt-0.5">
                    {activeItem.role} · <span className="text-[#111111] dark:text-neutral-200 font-bold">{activeItem.company}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Carousel Controls: Chevrons directly integrated alongside dotted positions */}
        <div className="flex items-center justify-center gap-4 mt-6 sm:mt-8 shrink-0">
          <button
            type="button"
            onClick={handlePrev}
            aria-label="Previous testimonial"
            className="w-9 h-9 rounded-full border border-[#E5E5E2] dark:border-[#3a3b42] bg-white dark:bg-[#202126] text-[#111111] dark:text-white flex items-center justify-center hover:bg-[#111111] hover:text-white dark:hover:bg-white dark:hover:text-black hover:border-[#111111] transition-all cursor-pointer shadow-xs active:scale-95"
          >
            <ChevronLeft className="w-4.5 h-4.5" />
          </button>

          {/* Dotted positions */}
          <div className="flex items-center gap-2 px-2">
            {testimonials.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setCurrentIndex(i)}
                aria-label={`Go to testimonial ${i + 1}`}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  currentIndex === i
                    ? "w-6 bg-[#111111] dark:bg-white"
                    : "w-2 bg-[#D1D1CE] dark:bg-[#3a3b42] hover:bg-[#8A8A87]"
                }`}
              />
            ))}
          </div>

          <button
            type="button"
            onClick={handleNext}
            aria-label="Next testimonial"
            className="w-9 h-9 rounded-full border border-[#E5E5E2] dark:border-[#3a3b42] bg-white dark:bg-[#202126] text-[#111111] dark:text-white flex items-center justify-center hover:bg-[#111111] hover:text-white dark:hover:bg-white dark:hover:text-black hover:border-[#111111] transition-all cursor-pointer shadow-xs active:scale-95"
          >
            <ChevronRight className="w-4.5 h-4.5" />
          </button>
        </div>
      </div>
    </section>
  );
}

export default Testimonial;
