import React from 'react';
import { ArrowDown, Plus, Image as ImageIcon } from 'lucide-react';
import { motion } from 'motion/react';
import { Magnetic } from './Magnetic';
import { GridPulse } from '@/components/ui/grid-pulse';

interface HeroProps {
  onSeeWork: () => void;
  onNavigateAbout: () => void;
  onSelectProject?: (slug: string) => void;
  onOpenResume?: () => void;
}

interface CompanyLogoItem {
  id: string;
  name: string;
  logoUrl?: string; // Ready for user uploaded logo images
}

const companyLogos: CompanyLogoItem[] = [
  { id: 'techm', name: 'Tech Mahindra', logoUrl: '' },
  { id: 'reclaimz', name: 'Reclaimz', logoUrl: '' },
  { id: 'unilever', name: 'Unilever', logoUrl: '' },
  { id: 'qmentis', name: 'Qmentis AI', logoUrl: '' },
  { id: 'equintis', name: 'Equintis', logoUrl: '' },
  { id: 'hyperion', name: 'Hyperion', logoUrl: '' },
  { id: 'sentinel', name: 'Sentinel Health', logoUrl: '' },
];

export const Hero: React.FC<HeroProps> = ({
  onSeeWork,
}) => {
  // Triple list for seamless continuous infinite marquee loop
  const tickerItems = [...companyLogos, ...companyLogos, ...companyLogos];

  return (
    <section
      id="hero"
      className="relative w-full min-h-screen lg:h-screen lg:max-h-[1080px] snap-start bg-white dark:bg-[#18181b] text-[#111111] dark:text-[#F3F4F6] pt-28 sm:pt-32 pb-6 sm:pb-8 flex flex-col justify-between overflow-visible lg:overflow-hidden select-none transition-colors duration-250"
    >
      {/* Interactive Light-weight Grid Pulse Background */}
      <GridPulse
        cell={32}
        reach={2.4}
        ambient={1}
        maxLit={65}
        avoid="[data-grid-avoid]"
        className="opacity-70 pointer-events-none"
      />

      {/* Centered Hero Content */}
      <div className="relative z-10 max-w-[960px] w-full mx-auto px-6 sm:px-10 lg:px-12 my-auto flex flex-col items-center justify-center text-center">
        {/* 1. Status Indicator Badge */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="inline-flex items-center gap-2 mb-5 sm:mb-6"
        >
          <span className="w-2 h-2 rounded-full bg-[#10B981] inline-block shrink-0 shadow-[0_0_8px_rgba(16,185,129,0.5)] animate-pulse" />
          <span className="font-sans text-[11px] sm:text-[12.5px] font-bold tracking-wider text-[#6B7280] dark:text-neutral-400">
            Available for project work.
          </span>
        </motion.div>

        {/* 2. Refined 2-Line Headline */}
        <h1 data-grid-avoid className="font-display tracking-[-0.035em] text-center w-full">
          <motion.span
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.6,
              delay: 0.15,
              ease: [0.22, 1, 0.36, 1],
            }}
            style={{ fontWeight: 600, fontStyle: 'normal' }}
            className="block text-[#111111] dark:text-white text-[40px] sm:text-[56px] md:text-[68px] lg:text-[78px] leading-[1.08] tracking-[-0.03em] font-semibold not-italic"
          >
            Making complex products
          </motion.span>
          <motion.span
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.6,
              delay: 0.28,
              ease: [0.22, 1, 0.36, 1],
            }}
            style={{ fontStyle: 'italic', fontWeight: 600 }}
            className="block italic text-[#8fc33b] text-[40px] sm:text-[56px] md:text-[68px] lg:text-[78px] leading-[1.08] tracking-[-0.03em] mt-1 sm:mt-2 font-semibold"
          >
            feel remarkably simple.
          </motion.span>
        </h1>

        {/* 3. Subtitle Description */}
        <motion.p
          data-grid-avoid
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.45 }}
          style={{ lineHeight: '28px' }}
          className="mt-6 sm:mt-7 text-[16px] sm:text-[18px] lg:text-[19px] text-[#4A4A4A] dark:text-[#A3A3A3] font-sans font-normal max-w-[620px] mx-auto text-center"
        >
          I'm Mihir, a product designer with 5+ years of experience who gets close to messy problems until they become simple, useful experiences.
        </motion.p>

        {/* 4. Action CTA: "See work" */}
        <motion.div
          data-grid-avoid
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.55 }}
          className="mt-8 sm:mt-10 flex items-center justify-center"
        >
          <Magnetic strength={0.2} activeScale={1.03}>
            <button
              type="button"
              onClick={onSeeWork}
              className="px-8 py-3.5 rounded-full bg-[#0D0D0D] dark:bg-white hover:bg-black dark:hover:bg-neutral-200 text-white dark:text-[#111111] font-sans text-[14px] sm:text-[15px] font-bold tracking-tight shadow-sm flex items-center gap-2 cursor-pointer transition-all hover:shadow-[0_8px_20px_rgba(0,0,0,0.15)] focus-visible:outline-2 focus-visible:outline-[#111111]"
            >
              <span className="font-bold">See work</span>
              <ArrowDown className="w-3.5 h-3.5 text-white/90 dark:text-black/90 animate-bounce" />
            </button>
          </Magnetic>
        </motion.div>
      </div>

      {/* ================= BOTTOM BAR: SCROLL EXPLORE & CONTINUOUS MOVING LOGO PLACEHOLDERS ================= */}
      <div className="w-full max-w-[1360px] mx-auto px-6 sm:px-10 lg:px-12 mt-auto pt-4">
        {/* Scroll Explore */}
        <div className="flex items-center justify-between font-mono text-[10px] sm:text-[11px] text-[#8A8A87] dark:text-neutral-400 tracking-[0.16em] uppercase pb-2">
          <button
            type="button"
            onClick={onSeeWork}
            className="flex items-center gap-1.5 hover:text-[#111111] dark:hover:text-white transition-colors cursor-pointer group"
          >
            <span className="w-4 h-4 rounded-full border border-[#8A8A87] dark:border-neutral-600 group-hover:border-[#111111] dark:group-hover:border-white flex items-center justify-center text-[10px]">
              <Plus className="w-2.5 h-2.5 group-hover:rotate-90 transition-transform" />
            </span>
            <span className="font-bold">SCROLL TO EXPLORE</span>
          </button>
        </div>

        {/* Continuous Running Logo Image Placeholders Marquee (without "Trusted across" label) */}
        <div className="relative w-full overflow-hidden pt-2 pb-2">
          {/* Gradient edge masks */}
          <div className="absolute left-0 top-0 bottom-0 w-12 sm:w-20 bg-gradient-to-r from-white dark:from-[#0D0D0D] to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-12 sm:w-20 bg-gradient-to-l from-white dark:from-[#0D0D0D] to-transparent z-10 pointer-events-none" />

          {/* Marquee Track */}
          <div className="animate-ticker flex items-center gap-4 sm:gap-6 py-1 cursor-default">
            {tickerItems.map((company, index) => (
              <div
                key={`${company.id}-${index}`}
                className="h-10 px-4 sm:px-5 rounded-xl border border-dashed border-[#D5D5D1] dark:border-neutral-700 bg-[#F8F8F7] dark:bg-neutral-800/80 hover:border-[#111111] dark:hover:border-neutral-400 transition-all flex items-center justify-center gap-2.5 shrink-0 group"
                title={`${company.name} - Logo image placeholder (ready for image upload)`}
              >
                {company.logoUrl ? (
                  <img
                    src={company.logoUrl}
                    alt={company.name}
                    referrerPolicy="no-referrer"
                    className="max-h-6 max-w-[110px] object-contain opacity-85 group-hover:opacity-100 transition-opacity"
                  />
                ) : (
                  <div className="flex items-center gap-2 font-mono text-[11px] sm:text-[12px] font-bold text-[#555555] dark:text-neutral-300 group-hover:text-[#111111] dark:group-hover:text-white transition-colors">
                    <div className="w-4 h-4 rounded border border-dashed border-[#9E9E9A] dark:border-neutral-600 flex items-center justify-center">
                      <ImageIcon className="w-2.5 h-2.5 text-[#888888] dark:text-neutral-400" />
                    </div>
                    <span className="tracking-wide uppercase">{company.name}</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#E8E8E4] dark:bg-neutral-700 text-[#777777] dark:text-neutral-400 font-mono">
                      LOGO
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
